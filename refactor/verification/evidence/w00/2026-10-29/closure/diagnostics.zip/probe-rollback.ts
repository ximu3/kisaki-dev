import assert from 'node:assert/strict'
import { spawn, execFile } from 'node:child_process'
import { once } from 'node:events'
import fs from 'node:fs/promises'
import { syncBuiltinESMExports } from 'node:module'
import { join, resolve } from 'node:path'
import { promisify } from 'node:util'
import { replaceOutput } from '@kisaki3/tooling/output'

const root = process.cwd()
const directory = resolve(root, '.local/w00-closure')
const project = await fs.mkdtemp(join(directory, 'rollback-fixture-'))
const output = join(project, 'dist')
const execute = promisify(execFile)
const originalRename = fs.rename
await fs.mkdir(output)
await fs.writeFile(join(output, 'previous.txt'), 'previous complete output')
let holder: ReturnType<typeof spawn> | undefined
let holderClosed: Promise<unknown> | undefined
let evidence: unknown

fs.rename = async function observeBlockedAdoption(source, destination) {
  try {
    return await originalRename(source, destination)
  } catch (cause) {
    if (String(destination) === output && String(source).includes('output-staging')) {
      const candidateFile = join(String(source), 'next.txt')
      const input = join(directory, 'rollback-locked-files.json')
      await fs.writeFile(input, JSON.stringify([candidateFile]))
      const query = await execute('C:/Program Files/PowerShell/7/pwsh.exe', ['-NoProfile', '-File', join(directory, 'query-file-users.ps1'), '-InputFile', input], { windowsHide: true })
      const users = JSON.parse(query.stdout)
      assert(users.processes.some((entry: { pid: number }) => entry.pid === holder?.pid))
      evidence = { holderPid: holder?.pid, users, originalFailure: { code: (cause as NodeJS.ErrnoException).code, syscall: (cause as NodeJS.ErrnoException).syscall }, previousOutputDuringFailure: await fs.readFile(join(`${source}.previous`, 'previous.txt'), 'utf8') }
      holder?.stdin?.end('\n')
      await holderClosed
    }
    throw cause
  }
}
syncBuiltinESMExports()

try {
  await assert.rejects(replaceOutput(project, 'dist', async (candidate) => {
    const next = join(candidate, 'next.txt')
    await fs.writeFile(next, 'next complete output')
    holder = spawn('C:/Program Files/PowerShell/7/pwsh.exe', ['-NoProfile', '-File', join(directory, 'hold-file.ps1'), '-Path', next], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] })
    holderClosed = once(holder, 'close')
    await new Promise<void>((ready, reject) => {
      holder!.stdout!.setEncoding('utf8').on('data', (text) => { if (String(text).includes('ready:')) ready() })
      holder!.once('error', reject)
      holder!.once('close', () => reject(new Error('Lock holder exited before readiness')))
    })
  }), { code: 'EPERM', syscall: 'rename' })

  assert.equal(await fs.readFile(join(output, 'previous.txt'), 'utf8'), 'previous complete output')
  assert.deepEqual(await fs.readdir(output), ['previous.txt'])
  assert.deepEqual(await fs.readdir(join(project, '.cache/output-staging')), [])
  assert(evidence)

  fs.rename = originalRename
  syncBuiltinESMExports()
  await replaceOutput(project, 'dist', async (candidate) => {
    await fs.writeFile(join(candidate, 'next.txt'), 'next complete output')
  })
  assert.deepEqual(await fs.readdir(output), ['next.txt'])
  await fs.writeFile(join(directory, 'rollback-probe.json'), JSON.stringify({ evidence, oldOutputRestored: true, failedCandidateRemoved: true, explicitSubsequentBuildPassed: true, automaticRetriesAdded: false }, null, 2) + '\n')
  console.info(JSON.stringify({ oldOutputRestored: true, failedCandidateRemoved: true, explicitSubsequentBuildPassed: true }))
} finally {
  fs.rename = originalRename
  syncBuiltinESMExports()
  if (holder && holder.exitCode === null) holder.stdin?.end('\n')
  await holderClosed
  assert(project.startsWith(directory + '\\'))
  await fs.rm(project, { recursive: true, force: true })
}
