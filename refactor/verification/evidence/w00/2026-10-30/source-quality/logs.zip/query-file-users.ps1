param([Parameter(Mandatory)][string]$InputFile)
$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Text;

public static class KisakiFileUsers
{
    [StructLayout(LayoutKind.Sequential)]
    public struct ProcessIdentity
    {
        public uint ProcessId;
        public System.Runtime.InteropServices.ComTypes.FILETIME StartedAt;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct ProcessInfo
    {
        public ProcessIdentity Process;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string ApplicationName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string ServiceName;
        public uint ApplicationType;
        public uint Status;
        public uint SessionId;
        [MarshalAs(UnmanagedType.Bool)] public bool Restartable;
    }

    public sealed class Report
    {
        public uint StartStatus;
        public uint RegisterStatus;
        public uint ListStatus;
        public uint RebootReasons;
        public ProcessInfo[] Processes = new ProcessInfo[0];
    }

    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    private static extern uint RmStartSession(out uint handle, uint flags, StringBuilder key);
    [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)]
    private static extern uint RmRegisterResources(uint handle, uint fileCount, [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.LPWStr)] string[] files, uint applicationCount, ProcessIdentity[] applications, uint serviceCount, string[] services);
    [DllImport("rstrtmgr.dll")]
    private static extern uint RmGetList(uint handle, out uint needed, ref uint count, [In, Out] ProcessInfo[] processes, ref uint rebootReasons);
    [DllImport("rstrtmgr.dll")]
    private static extern uint RmEndSession(uint handle);

    public static Report Query(string[] paths)
    {
        var report = new Report();
        uint handle;
        report.StartStatus = RmStartSession(out handle, 0, new StringBuilder(33));
        if (report.StartStatus != 0) return report;
        try
        {
            report.RegisterStatus = RmRegisterResources(handle, (uint)paths.Length, paths, 0, null, 0, null);
            if (report.RegisterStatus != 0) return report;
            uint needed;
            uint count = 0;
            report.ListStatus = RmGetList(handle, out needed, ref count, null, ref report.RebootReasons);
            for (int attempt = 0; report.ListStatus == 234 && attempt < 3; attempt++)
            {
                var processes = new ProcessInfo[needed];
                count = needed;
                report.ListStatus = RmGetList(handle, out needed, ref count, processes, ref report.RebootReasons);
                if (report.ListStatus == 0)
                {
                    Array.Resize(ref processes, (int)count);
                    report.Processes = processes;
                }
            }
            return report;
        }
        finally { RmEndSession(handle); }
    }
}
'@

$w00Paths = [string[]](Get-Content -Raw -LiteralPath $InputFile | ConvertFrom-Json)
$w00Report = [KisakiFileUsers]::Query($w00Paths)
$w00Result = [ordered]@{
    startStatus = $w00Report.StartStatus
    registerStatus = $w00Report.RegisterStatus
    listStatus = $w00Report.ListStatus
    rebootReasons = $w00Report.RebootReasons
    processes = @($w00Report.Processes | ForEach-Object {
        [ordered]@{
            pid = $_.Process.ProcessId
            name = $_.ApplicationName
            service = $_.ServiceName
            type = $_.ApplicationType
            status = $_.Status
            sessionId = $_.SessionId
            restartable = $_.Restartable
        }
    })
}
$w00Result | ConvertTo-Json -Depth 5 -Compress
