param([Parameter(Mandatory)][string]$Path)
$ErrorActionPreference = 'Stop'
$w00Stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
try {
    [Console]::Out.WriteLine("ready:$PID")
    [Console]::Out.Flush()
    [void][Console]::In.ReadLine()
} finally {
    $w00Stream.Dispose()
}
