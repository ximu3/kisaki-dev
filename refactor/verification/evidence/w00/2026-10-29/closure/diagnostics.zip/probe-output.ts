import assert from 'node:assert/strict'
import { spawn, execFile } from 'node:child_process'
import { once } from 'node:events'
import fs from 'node:fs/promises'
import { syncBuiltinESMExports } from 'node:module'
import { basename, join, resolve } from 'node:path'
import { promisify } from 'node:util'
import { pathToFileURL } from 'node:url'

const root = process.cwd()
const directory = resolve(root, '.local/w00-closure')
const powershell = 'C:/Program Files/PowerShell/7/pwsh.exe'
const execute = promisify(execFile)
const originalRename = fs.rename
const failures: unknown[] = []
let phase = 'controlled lock'

async function queryUsers(paths: string[]) {
  const input = join(directory, 'query-files.json')
  await fs.writeFile(input, JSON.stringify(paths))
  const result = await execute(powershell, ['-NoProfile', '-File', join(directory, 'query-file-users.ps1'), '-InputFile', input], { windowsHide: true })
  return JSON.parse(result.stdout)
}

const fixture = await fs.mkdtemp(join(directory, 'lock-fixture-'))
const heldFile = join(fixture, 'entry.js')
await fs.writeFile(heldFile, 'export const value = 1\n')
const holder = spawn(powershell, ['-NoProfile', '-File', join(directory, 'hold-file.ps1'), '-Path', heldFile], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] })
const holderClosed = once(holder, 'close')
let holderError = ''
holder.stderr.setEncoding('utf8').on('data', (chunk) => { holderError += chunk })
await new Promise<void>((resolveReady, reject) => {
  holder.stdout.setEncoding('utf8').on('data', (chunk) => {
    if (String(chunk).includes('ready:')) resolveReady()
  })
  holder.once('error', reject)
  holder.once('close', () => reject(new Error(`Holder closed before readiness: ${holderError}`)))
})
try {
  const observed = await queryUsers([heldFile])
  assert.equal(observed.startStatus, 0)
  assert.equal(observed.registerStatus, 0)
  assert.equal(observed.listStatus, 0)
  assert(observed.processes.some((process: { pid: number }) => process.pid === holder.pid))
  await assert.rejects(originalRename(fixture, `${fixture}-moved`), { code: 'EPERM' })
  await fs.writeFile(join(directory, 'controlled-lock.json'), JSON.stringify({ holderPid: holder.pid, observed, directoryRenameRejected: true }, null, 2) + '\n')
} finally {
  holder.stdin.end('\n')
  await holderClosed
  assert(fixture.startsWith(directory + '\\'))
  await fs.rm(fixture, { recursive: true, force: true })
}

async function snapshot(path: string) {
  try {
    const attributes = await fs.stat(path)
    const entries = attributes.isDirectory() ? await fs.readdir(path) : []
    return { exists: true, directory: attributes.isDirectory(), ino: attributes.ino, mode: attributes.mode, entries }
  } catch (error) {
    return { exists: false, error: String(error) }
  }
}

fs.rename = async (oldPath, newPath) => {
  try {
    return await originalRename(oldPath, newPath)
  } catch (cause) {
    const source = String(oldPath)
    const destination = String(newPath)
    if (source.includes('output-staging') && basename(destination) === 'dist') {
      const files = (await fs.readdir(source, { withFileTypes: true })).filter((entry) => entry.isFile()).map((entry) => join(source, entry.name))
      const observation = { at: new Date().toISOString(), phase, pid: process.pid, source, destination, error: { code: (cause as NodeJS.ErrnoException).code, message: String(cause) }, sourceState: await snapshot(source), destinationState: await snapshot(destination), users: files.length ? await queryUsers(files) : null, activeResources: process.getActiveResourcesInfo() }
      failures.push(observation)
      await fs.writeFile(join(directory, 'rename-failures.json'), JSON.stringify(failures, null, 2) + '\n')
    }
    throw cause
  }
}
syncBuiltinESMExports()

const runs: unknown[] = []
try {
  for (const name of ['extension-sdk', 'extension-distribution']) {
    const packageRoot = join(root, 'clients/desktop/packages', name)
    const { buildPackage } = await import(pathToFileURL(join(packageRoot, 'tools/build.ts')).href)
    process.chdir(packageRoot)
    for (let iteration = 1; iteration <= 20; iteration++) {
      phase = `${name} ${iteration}`
      const started = performance.now()
      try {
        await buildPackage()
        runs.push({ name, iteration, passed: true, milliseconds: performance.now() - started })
      } catch (error) {
        runs.push({ name, iteration, passed: false, error: String(error), outputAfterFailure: await snapshot(join(packageRoot, 'dist')) })
        throw error
      }
    }
  }
} finally {
  process.chdir(root)
  fs.rename = originalRename
  syncBuiltinESMExports()
  await fs.writeFile(join(directory, 'build-probe.json'), JSON.stringify({ runs, observedRenameFailures: failures.length, elevated: false }, null, 2) + '\n')
  console.info(JSON.stringify({ runs: runs.length, failures: failures.length }))
}
