import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { basename, join } from 'node:path';
import { promisify } from 'node:util';
const originalRename = fs.rename;
const root = process.env.KISAKI_RENAME_PROBE_ROOT;
const execute = promisify(execFile);
async function snapshot(path) {
    try {
        const stat = await fs.stat(path);
        return { exists: true, ino: stat.ino, mode: stat.mode, entries: stat.isDirectory() ? await fs.readdir(path) : [] };
    }
    catch (cause) {
        return { exists: false, error: String(cause) };
    }
}
if (root) {
    const captures = join(root, 'artifacts/configuration-comments/2026-10-30/rename-captures');
    await fs.mkdir(captures, { recursive: true });
    fs.rename = async function observeRename(source, destination) {
        try {
            return await originalRename(source, destination);
        }
        catch (cause) {
            const oldPath = String(source);
            const newPath = String(destination);
            if ((oldPath.includes('output-staging') || newPath.includes('output-staging')) && oldPath.toLowerCase().startsWith(root.toLowerCase())) {
                const record = join(captures, `${Date.now()}-${process.pid}`);
                const observation = { at: new Date().toISOString(), pid: process.pid, parentPid: process.ppid, command: process.argv.map((value, index) => index === 0 ? basename(value) : value), source: oldPath, destination: newPath, error: { code: cause.code, message: String(cause) }, sourceState: await snapshot(oldPath), destinationState: await snapshot(newPath), activeResources: process.getActiveResourcesInfo() };
                try {
                    const entries = await fs.readdir(oldPath, { withFileTypes: true, recursive: true });
                    const files = entries.filter((entry) => entry.isFile()).map((entry) => join(entry.parentPath, entry.name));
                    await fs.writeFile(`${record}-files.json`, JSON.stringify(files));
                    if (files.length) {
                        const result = await execute('C:/Program Files/PowerShell/7/pwsh.exe', ['-NoProfile', '-File', join(root, 'artifacts/configuration-comments/2026-10-30/query-file-users.ps1'), '-InputFile', `${record}-files.json`], { windowsHide: true });
                        observation.users = JSON.parse(result.stdout);
                    }
                }
                catch (diagnosticFailure) {
                    observation.diagnosticFailure = String(diagnosticFailure);
                }
                await fs.writeFile(`${record}.json`, JSON.stringify(observation, null, 2) + '\n');
            }
            throw cause;
        }
    };
    syncBuiltinESMExports();
}
